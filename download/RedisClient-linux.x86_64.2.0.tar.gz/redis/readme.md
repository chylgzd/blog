git clone https://github.com/caoxinyu/RedisClient
mvn clean package -P linux.x86_64
java -jar redisclient-linux.x86_64.2.0.jar
