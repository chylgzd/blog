import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Driver;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class DBConnection {
	
	/**
	 * SCHEM_NAME String => schema name
	 */
	public static final int SCHEM_NAME = 1;
	
	/**
	 * TABLE_NAME String => table name
	 */
	public static final int TABLE_NAME = 3;
	
	/**
	 * TABLE_TYPE String => table name
	 */
	public static final int TABLE_TYPE = 4;
	
	private Connection connection;
	
	private DatabaseMetaData metaData;

	public DBConnection() {
		connection = null;
		metaData = null;
	}
	
	/**
	 * Establish connection with the server
	 * 
	 * @throws MalformedURLException
	 * @throws ClassNotFoundException
	 * @throws IllegalAccessException
	 * @throws InstantiationException
	 */
	public void connect(ConnectionInfo connectionInfo) throws SQLException,
			MalformedURLException, InstantiationException,
			IllegalAccessException, ClassNotFoundException {
		URL driverURL = new URL("file:" + connectionInfo.getPathfile().trim());
		URL[] drivers = new URL[1];
		drivers[0] = driverURL;
		ClassLoader driverClassLoader = 
			new URLClassLoader(drivers, getClass().getClassLoader());
		Driver driver = (Driver) Class.forName(connectionInfo.getClassname(), true,
				driverClassLoader).newInstance();
		java.util.Properties p = new java.util.Properties();
		p.put("user", connectionInfo.getLogin());
		p.put("password", connectionInfo.getPassword());
		connection = driver.connect(connectionInfo.getJdbcurl(), p);
		metaData = connection.getMetaData();
	}

	public PreparedStatement getpreparedSql(String sql) throws SQLException {
		return connection.prepareStatement(sql);
	}

	public String[] getCatalogs() throws SQLException {
		Vector vCatalog = new Vector();
		ResultSet res = metaData.getCatalogs();
		while (res.next()) {
			String name = res.getString(SCHEM_NAME);
			if (!"".equals(name) && !vCatalog.contains(name)) {
				vCatalog.add(name);
			}
		}
		res.close();
		
		String catalog[] = new String[vCatalog.size()];
		vCatalog.copyInto(catalog);
		return catalog;
	}

	public String[] getSchemas() throws SQLException {
		Vector vSchema = new Vector();
		ResultSet res = metaData.getSchemas();
		while (res.next()) {
			String name = res.getString(SCHEM_NAME);
			if (!"".equals(name) && !vSchema.contains(name)) {
				vSchema.add(name);
			}
		}
		res.close();

		String schema[] = new String[vSchema.size()];
		vSchema.copyInto(schema);
		return schema;
	}
	
	public Vector getTables(String catalog, String schema) throws SQLException {
		Vector vTable = new Vector();
		metaData = connection.getMetaData();
		String[] names = {"TABLE", "SYSTEM TABLE"};
		ResultSet res = metaData.getTables(catalog, schema, "%", names);
		while (res.next()) {
			vTable.add(res.getString(TABLE_NAME));
		}
		res.close();
		return vTable;
	}
	
	public Vector getTablesFromHiRDB(String catalog, String schema) throws SQLException {
		Vector vTable = new Vector();
		metaData = connection.getMetaData();
		String[] names = {"BASE TABLE", "SYSTEM TABLE"};
		ResultSet res = metaData.getTables(catalog, schema, "%", names);
		while (res.next()) {
			vTable.add(res.getString(TABLE_NAME));
		}
		res.close();
		return vTable;
	}
	
	public ResultSet getAttributes(String catalog, String schema,String table) throws SQLException {
		return metaData.getColumns(catalog, schema, table, "%");
	}
	
	/** 
	 * Close connection 
	 */
	public void close() throws SQLException {
		connection.close();
		connection = null;
		metaData = null;
	}

	public DatabaseMetaData getMetaData() {
		return metaData;
	}
}
