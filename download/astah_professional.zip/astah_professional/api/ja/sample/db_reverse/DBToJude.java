import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.change_vision.jude.api.inf.editor.ERModelEditor;
import com.change_vision.jude.api.inf.editor.ModelEditorFactory;
import com.change_vision.jude.api.inf.editor.TransactionManager;
import com.change_vision.jude.api.inf.exception.BadTransactionException;
import com.change_vision.jude.api.inf.exception.InvalidEditingException;
import com.change_vision.jude.api.inf.exception.LicenseNotFoundException;
import com.change_vision.jude.api.inf.exception.ProjectLockedException;
import com.change_vision.jude.api.inf.model.IERAttribute;
import com.change_vision.jude.api.inf.model.IERDatatype;
import com.change_vision.jude.api.inf.model.IERDomain;
import com.change_vision.jude.api.inf.model.IEREntity;
import com.change_vision.jude.api.inf.model.IERIndex;
import com.change_vision.jude.api.inf.model.IERModel;
import com.change_vision.jude.api.inf.model.IERRelationship;
import com.change_vision.jude.api.inf.model.IERSchema;
import com.change_vision.jude.api.inf.model.IERSubtypeRelationship;
import com.change_vision.jude.api.inf.model.IModel;
import com.change_vision.jude.api.inf.project.ProjectAccessor;
import com.change_vision.jude.api.inf.project.ProjectAccessorFactory;

public class DBToJude {
	
	private ERModelEditor editor;
	
	private IERModel erModel;
	
	private Map fkInfo;
	
	private Map indexMap;
	
	boolean isDebug = false;
	
	public void importToJude(String judePath, List tables, List relationships) throws LicenseNotFoundException, 
			ProjectLockedException, InvalidEditingException, Throwable {
		ProjectAccessor prjAccessor = ProjectAccessorFactory.getProjectAccessor();
	    prjAccessor.create(judePath, false);
	    IModel project = prjAccessor.getProject();
		if (project == null) {
			return;
		}		
		try {
			TransactionManager.beginTransaction();
			editor = ModelEditorFactory.getERModelEditor();
			erModel = editor.createERModel(project, "ER Model");
			fkInfo = new HashMap();
			indexMap = new HashMap();
			importTable(tables);
			importRelationships(relationships);			
			showTableCount(tables.size());
			TransactionManager.endTransaction();
		} catch (BadTransactionException e) {
			TransactionManager.abortTransaction();
		}		
        prjAccessor.save();
        prjAccessor.close();
	}
	
	public void showTableCount(int count) {		
	}

	private void importTable(List tables) throws InvalidEditingException {
		for (Iterator it = tables.iterator(); it.hasNext(); ) {
			TableInfo tInfo = (TableInfo) it.next();
			createTable(tInfo);
			showImportingTable(tInfo.getName());
		}
	}
	
	public void showImportingTable(String name) {		
	}
	
	private void createTable(TableInfo tInfo) throws InvalidEditingException {		
		IERSchema defaultSchema = erModel.getSchemata()[0];
		IEREntity entity = editor.createEREntity(defaultSchema, tInfo.getName(), tInfo.getName());
		entity.setType(tInfo.getType());
		entity.setDefinition(tInfo.getDefinition());
		addAttributes(tInfo, entity);
		addIndexes(tInfo, entity);
	}
	
	private void addIndexes(TableInfo tInfo, IEREntity entity)
			throws InvalidEditingException {
		List missedInfo = new ArrayList();
		for (Iterator it = tInfo.getIndexes().iterator(); it.hasNext(); ) {
			IndexInfo indexInfo = (IndexInfo) it.next();
			IERAttribute[] erAttributes =  getAttributes(entity, indexInfo.getAttributes());
			if (erAttributes.length != 0) {
				IERIndex newIndex = editor.createERIndex(indexInfo.getName(), entity, indexInfo.isUnique(), true, erAttributes);
				indexMap.put(newIndex, indexMap.get(indexInfo.getAttributes()));
			} else {
				indexMap.put(indexInfo, indexMap.get(indexInfo.getAttributes()));
				missedInfo.add(indexInfo);
			}
			indexMap.remove(indexInfo.getAttributes());
		}
		if (!missedInfo.isEmpty()) {
			indexMap.put(entity, missedInfo);
		}
	}
	
	private IERAttribute[] getAttributes(IEREntity entity, List attrNames) {
		List attrs = new ArrayList();
		List missed = new ArrayList();
		for (Iterator it = attrNames.iterator(); it.hasNext(); ) {
			String attrName = (String) it.next();
			IERAttribute erAttr = getAttribute(entity, attrName);
			if (erAttr == null) {
				missed.add(attrName);
			} else {
				attrs.add(erAttr);
			}			
		}
		if (!missed.isEmpty()) {
			indexMap.put(attrNames, missed);
		}
		return (IERAttribute[]) attrs.toArray(new IERAttribute[0]);
	}
	
	private void addAttributes(TableInfo tInfo, IEREntity entity)
			throws InvalidEditingException {
		for (Iterator it = tInfo.getAttributes().iterator(); it.hasNext(); ) {
			AttributeInfo aInfo = (AttributeInfo) it.next();
			if (aInfo.isFK()) {
				fkInfo.put(tInfo.getName(), aInfo);
				continue;
			}
			IERAttribute attri = createAttribute(aInfo, entity);
			if (attri != null) {
				setAttributeInfo(attri, aInfo);
			}
		}
	}
	
	private void setAttributeInfo(IERAttribute attri, AttributeInfo aInfo) throws InvalidEditingException {
		attri.setPrimaryKey(aInfo.isPK());
		attri.setNotNull(aInfo.isPK() ? true : aInfo.isNotNull());
		attri.setDefaultValue(aInfo.getDefaultValue());
		attri.setDefinition(aInfo.getDefinition());
		String aLen = aInfo.getLength();
		String aPre = aInfo.getPrecision();
		StringBuffer lengthPrecision = new StringBuffer();
		lengthPrecision.append(aLen);
		lengthPrecision.append(("".equals(aLen) || "".equals(aPre)) ? "" : ",");
		lengthPrecision.append(aPre);
		attri.setLengthPrecision(lengthPrecision.toString());
	}
	
	private IERAttribute createAttribute(AttributeInfo aInfo, IEREntity entity) throws InvalidEditingException {
		DomainInfo dmInfo = aInfo.getDomain();
		DatatypeInfo dtInfo = aInfo.getDataType();
		if (!"".equals(dmInfo.getName())) {
			IERDomain iDomain = createDomain(dmInfo);
			return editor.createERAttribute(entity, aInfo.getName(), aInfo.getName(), iDomain);
		} else if (!"".equals(dtInfo.getName())) {
			IERDatatype datatype = createERDatatype(dtInfo);			
			return editor.createERAttribute(entity, aInfo.getName(), aInfo.getName(), datatype);
		}
		return null;
	}
	
	private IERDomain createDomain(DomainInfo dmInfo) throws InvalidEditingException {
		IERDomain iDomain = getDomain(dmInfo.getName());
		if (iDomain == null) {
			IERDatatype datatype = getDatatype(dmInfo.getDatatypeName());
			if (datatype == null) {
				datatype = editor.createERDatatype(erModel, dmInfo.getDatatypeName());
			}
			iDomain = editor.createERDomain(erModel, null, dmInfo.getName(), dmInfo.getName(), datatype);
		}
		//More api should be added in IERDomain for setting domain info
		return iDomain;
	}
	
	private IERDatatype createERDatatype(DatatypeInfo dtInfo) throws InvalidEditingException {
		IERDatatype datatype = getDatatype(dtInfo.getName());
		if (datatype == null) {
			datatype = editor.createERDatatype(erModel, dtInfo.getName());
			datatype.setLengthConstraint(dtInfo.getLengthConstraint());
			datatype.setPrecisionConstraint(dtInfo.getPrecisionConstraint());
		}
		String dLen = dtInfo.getDefaultLength();
		String dPre = dtInfo.getDefaultPrecision();
		StringBuffer lengthPrecision = new StringBuffer();
		lengthPrecision.append(dLen);
		lengthPrecision.append(("".equals(dLen) || "".equals(dPre)) ? "" : ",");		
		lengthPrecision.append(dPre);
		if (lengthPrecision.length() > 0) {
			datatype.setDefaultLengthPrecision(lengthPrecision.toString());
		}
		datatype.setDescription(dtInfo.getDescription());
		
		return datatype;
	}
	
	private IERDomain getDomain(String name) {
		IERDomain defaultDomain = erModel.getSchemata()[0].getDomains()[0];
		for (Iterator it = getAllChildDomains(defaultDomain).iterator(); it.hasNext(); ) {
			IERDomain domain = (IERDomain)it.next();
			if (domain.getName().equalsIgnoreCase(name)) {
				return domain;
			}
		}
		return null;
	}
	
	private List getAllChildDomains(IERDomain domain) {
		List domains = new ArrayList();	
		domains.add(domain);
		for (int i = 0; i < domain.getChildren().length; i++) {
			domains.addAll(getAllChildDomains(domain.getChildren()[i]));
		}
		return domains;
	}
	
	private IERDatatype getDatatype(String name) {
		IERDatatype[] datatypes = erModel.getSchemata()[0].getDatatypes();
		for (int i = 0; i < datatypes.length; i++) {
			IERDatatype datatype = datatypes[i];
			if (datatype.getName().equalsIgnoreCase(name)) {
				return datatype;
			}
		}
		return null;
	}
	
	private void importRelationships(List relationships) throws InvalidEditingException {		
		for (Iterator it = relationships.iterator(); it.hasNext(); ) {
			RelationshipInfo rInfo = (RelationshipInfo) it.next();
			IEREntity parent = getEntity(rInfo.getParentTable());
			IEREntity child = getEntity(rInfo.getChildTable());
			if (parent == null || child == null) {
				continue;
			}
			if (rInfo instanceof ERRelationshipInfo) {
				createERRelationship(parent, child, (ERRelationshipInfo) rInfo);				
			} else if (rInfo instanceof SubtypeRelationshipInfo) {
				createSubtypeRelationship(parent, child, (SubtypeRelationshipInfo) rInfo);				
			}
		}
	}
	
	private void createSubtypeRelationship(IEREntity parent, 
			IEREntity child, SubtypeRelationshipInfo subInfo) throws InvalidEditingException {
		String name = subInfo.getName();
		IERSubtypeRelationship subRelationship = 
			editor.createSubtypeRelationship(parent, child, name, name);
		subRelationship.setConclusive(subInfo.isConclusive());
		subRelationship.setDiscriminatorAttribute(
				getAttribute(parent, subInfo.getDiscriminatorAttribute()));
		subRelationship.setDefinition(subInfo.getDefinition());
	}
	
	private void createERRelationship(IEREntity parent, 
			IEREntity child, ERRelationshipInfo errInfo) throws InvalidEditingException {
		String name = errInfo.getName();
		IERRelationship relationship = null;
		if (errInfo.isIdentifying()) {
			debugCreateERRelationship(parent, child);
			relationship = editor.createIdentifyingRelationship(parent, child, name, name);
			checkRelationship(parent, child, errInfo, relationship);
			renameForeignKey(relationship, parent, child, errInfo);
			//[56_16_improve_fk2]
			doSpecialForChangeForeignKeyName(child, relationship);
		} else if (errInfo.isNonIdentifying()) {
			debugCreateERRelationship(parent, child);
			relationship = editor.createNonIdentifyingRelationship(parent, child, name, name);
			checkRelationship(parent, child, errInfo, relationship);
			renameForeignKey(relationship, parent, child, errInfo);
			//[56_16_improve_fk2]
			doSpecialForChangeForeignKeyName(child, relationship);
		} else if (errInfo.isMultiToMulti()) {
			relationship = editor.createMultiToMultiRelationship(parent, child, name, name);
		}
		relationship.setVerbPhraseParent(errInfo.getVerbPhraseParent());
		relationship.setVerbPhraseChild(errInfo.getVerbPhraseChild());
		relationship.setParentRequired(errInfo.isParentRequired());
		relationship.setDefinition(errInfo.getDefinition());
	}

	private void debugCreateERRelationship(IEREntity parent, IEREntity child) {
		//parent
		System.out.println("[P]Entity       :=" + parent.getName());
		IERAttribute[] primaryKeys = parent.getPrimaryKeys();
		if (primaryKeys.length > 0){
			debug("[P]Entity     PK:=" + primaryKeys[0].getName() + " : " + primaryKeys[0].getDatatype());
		}
		IERAttribute[] nonPrimaryKeys = parent.getNonPrimaryKeys();
		if (nonPrimaryKeys.length > 0){
			debug("[P]Entity Non-PK:=" + nonPrimaryKeys[0].getName() + " : " + nonPrimaryKeys[0].getDatatype());
		}
		
		//child
		debug("[C]Entity       :=" + child.getName());
		primaryKeys = child.getPrimaryKeys();
		if (primaryKeys.length > 0){
			debug("[C]Entity     PK:=" + primaryKeys[0].getName() + " : " + primaryKeys[0].getDatatype());
		}
		nonPrimaryKeys = child.getNonPrimaryKeys();
		if (nonPrimaryKeys.length > 0){
			debug("[C]Entity Non-PK:=" + nonPrimaryKeys[0].getName() + " : " + nonPrimaryKeys[0].getDatatype());
		}
	}

	//[56_16_improve_fk2]
	private void doSpecialForChangeForeignKeyName(IEREntity child,
			IERRelationship relationship) throws InvalidEditingException {
		IERAttribute[] foreignKeys = relationship.getForeignKeys();
		if (foreignKeys.length > 0 ) {
			debug("Created Relationship:=" + relationship.getName());
		}
		for (int i = 0; i < foreignKeys.length; i++) {
			IERAttribute attribute = foreignKeys[i];
			debug("Created attribute:=" + attribute.getName() + " ; " + attribute.getDatatype().getName());
			DomainInfo dmInfo = getFKDomainInfo(child.getName());
			DatatypeInfo dtInfo = getFKDatatypeInfo(child.getName());
			AttributeInfo aInfo = getFKAttributeInfo(child.getName());
			if (dmInfo != null && !"".equals(dmInfo.getName())) {
				IERDomain iDomain = createDomain(dmInfo);
				attribute.setDomain(iDomain);
			} else if (dtInfo != null && !"".equals(dtInfo.getName())) {
				IERDatatype datatype = createERDatatype(dtInfo);	
				attribute.setDatatype(datatype);
				attribute.setDefaultValue(aInfo.getDefaultValue());
				String aLen = aInfo.getLength();
				String aPre = aInfo.getPrecision();
				StringBuffer lengthPrecision = new StringBuffer();
				lengthPrecision.append(aLen);
				lengthPrecision.append(("".equals(aLen) || "".equals(aPre)) ? "" : ",");
				lengthPrecision.append(aPre);
				attribute.setLengthPrecision(lengthPrecision.toString());
				debug("Chaged attribute:=" + attribute.getName() + " ; " + attribute.getDatatype().getName());
			}
		}
	}

	private void checkRelationship(IEREntity parent, IEREntity child,
			ERRelationshipInfo errInfo, IERRelationship relationship)
			throws InvalidEditingException {
		IERIndex index = getKindOfRelationship(parent, errInfo);
		if (index != null) {
			addMissedAttributeForIndex(parent);
			relationship.setERIndex(index);
		}
		addMissedAttributeForIndex(child);
	}
	
	private void addMissedAttributeForIndex(IEREntity entity) throws InvalidEditingException {
		addMissedAttributes(entity);
		addMissedIndex(entity);
	}

	private void addMissedIndex(IEREntity entity)
			throws InvalidEditingException {
		List indexInfoes = (List)indexMap.get(entity);
		if (indexInfoes != null) {
			List missedInfo = new ArrayList();
			for (Iterator it = indexInfoes.iterator(); it.hasNext(); ) {
				IndexInfo indexInfo = (IndexInfo) it.next();
				List attributes = (List)indexMap.get(indexInfo);
				IERAttribute[] erAttrs = getAttributes(entity, attributes);
				if (erAttrs.length != 0) {
					IERIndex newIndex = editor.createERIndex(indexInfo.getName(), entity, indexInfo.isUnique(), true, erAttrs);						
					indexMap.remove(indexInfo);
					if (erAttrs.length != attributes.size()) {
						indexMap.put(newIndex, indexMap.get(attributes));
					}
				} else {
					indexMap.put(indexInfo, indexMap.get(attributes));
					missedInfo.add(indexInfo);
				}
				indexMap.remove(attributes);
			}
			indexMap.remove(entity);
			if (!missedInfo.isEmpty()) {
				indexMap.put(entity, missedInfo);
			}
		}
	}

	private void addMissedAttributes(IEREntity entity)
			throws InvalidEditingException {
		for (int i = 0; i < entity.getERIndices().length; i++) {
			IERIndex index = entity.getERIndices()[i];
			List attributes = (List)indexMap.get(index);
			if (attributes == null || attributes.isEmpty()) {
				continue;
			}
			IERAttribute[] erAttrs = getAttributes(entity, attributes);
			for (int j = 0; j < erAttrs.length; j++) {
				index.addERAttribute(erAttrs[j]);
			}
			if (erAttrs.length != attributes.size()) {
				indexMap.put(index, indexMap.get(attributes));
				indexMap.remove(attributes);
			} else {
				indexMap.remove(index);
			}
		}
	}
	
	private IERIndex getKindOfRelationship(IEREntity parent, ERRelationshipInfo errInfo) {
		for (int i = 0; i < parent.getERIndices().length; i++) {
			IERIndex index = parent.getERIndices()[i];
			List missedAttrs = (List)indexMap.get(index);
			List pks = new ArrayList();
			for (Iterator it = errInfo.getKeys().keySet().iterator(); it.hasNext(); ) {
				String pkName = (String) it.next();
				if (missedAttrs != null && missedAttrs.contains(pkName)) {
					continue;
				}
				IERAttribute pk = getAttribute(parent, pkName);
				pks.add(pk);
			}
			if (index.isUnique() && Arrays.asList(index.getERAttributes()).containsAll(pks)) {
				return index;
			}
		}
		return null;
	}
	
	private void renameForeignKey(IERRelationship relationship, 
			IEREntity parent, IEREntity child, 
			ERRelationshipInfo errInfo) throws InvalidEditingException {
		for (Iterator it = errInfo.getKeys().keySet().iterator(); it.hasNext(); ) {
			String parentKeyName = (String) it.next();
			String childKeyName = (String) errInfo.getKeys().get(parentKeyName);
			IERAttribute parentKey = getAttribute(parent, parentKeyName);
			IERAttribute childKey = getAttribute(child, childKeyName);
			if (parentKey != null) {
				IERAttribute fk = getReferenceFK(relationship, parentKey);
				if (fk == null) {
					continue;
				}
				boolean isNotNull = isFKNotNull(parent.getName(), childKeyName);
				fk.setNotNull(isNotNull);
				if (childKey != null && fk != childKey) {
					relationship.setForeignKey(parentKey, childKey);
				} else {
					if (!fk.getName().equals(childKeyName)) {
						fk.setLogicalName(childKeyName);
						fk.setPhysicalName(childKeyName);
					}
				}
			}
		}
	}
	
	private IERAttribute getReferenceFK(IERRelationship relationship, IERAttribute pk) {
    	for (int i = 0; i < pk.getReferencedForeignKeys().length; i++) {
			IERAttribute fk = (IERAttribute) pk.getReferencedForeignKeys()[i];
			if (fk.getReferencedRelationship() == relationship) {
				return fk;
			}			
		}
		return null;
	}
	
	private IERAttribute getAttribute(IEREntity entity, String name) {
		List attributes = new ArrayList();
		attributes.addAll(Arrays.asList(entity.getPrimaryKeys()));
		attributes.addAll(Arrays.asList(entity.getNonPrimaryKeys()));
		for (Iterator it = attributes.iterator(); it.hasNext(); ) {
			IERAttribute attri = (IERAttribute) it.next();
			if (attri.getName().equals(name)) {
				return attri;
			}
		}
		return null;
	}
	
	private IEREntity getEntity(String name) {
		IERSchema defaultSchema = erModel.getSchemata()[0];
		for (int i = 0; i < defaultSchema.getEntities().length; i++) {
			IEREntity entity = (IEREntity)defaultSchema.getEntities()[i];
			if (entity.getName().equals(name)) {
				return entity;
			}
		}
		return null;
	}
	
	private boolean isFKNotNull(String tableName, String fkName) {
		if (fkInfo.keySet().contains(tableName)) {
			return ((AttributeInfo)fkInfo.get(tableName)).isNotNull();
		}
		return false;
	}
	
	private DomainInfo getFKDomainInfo(String tableName) {
		if (fkInfo.keySet().contains(tableName)) {
			return ((AttributeInfo)fkInfo.get(tableName)).getDomain();
		}
		return null;
	}
	
	private DatatypeInfo getFKDatatypeInfo(String tableName) {
		if (fkInfo.keySet().contains(tableName)) {
			return ((AttributeInfo)fkInfo.get(tableName)).getDataType();
		}
		return null;
	}
	
	private AttributeInfo getFKAttributeInfo(String tableName) {
		if (fkInfo.keySet().contains(tableName)) {
			return ((AttributeInfo)fkInfo.get(tableName));
		}
		return null;
	}
	
	private void debug(String str) {
		if (isDebug) {
			System.out.println(str);
		}
	}
}
