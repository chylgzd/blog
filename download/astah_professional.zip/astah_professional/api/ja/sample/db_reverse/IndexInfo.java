import java.util.ArrayList;
import java.util.List;


public class IndexInfo {

	private String name;
	
	private String parentEntity;
	
	private List attributes;
	
	private boolean isUnique;
	
	public IndexInfo() {
		name = "";
		parentEntity = "";
		attributes = new ArrayList();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParentEntity() {
		return parentEntity;
	}

	public void setParentEntity(String parentEntity) {
		this.parentEntity = parentEntity;
	}

	public void addAttribute(String attrName) {
		attributes.add(attrName);
	}
	
	public List getAttributes() {
		return attributes;
	}

	public boolean isUnique() {
		return isUnique;
	}

	public void setUnique(boolean isUnique) {
		this.isUnique = isUnique;
	}
}
