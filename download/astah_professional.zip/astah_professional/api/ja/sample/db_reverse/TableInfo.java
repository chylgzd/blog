import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TableInfo {
	
	private String name;
	
	//Type for ER Entity, it should be "Event", "Resource","Summary" or ""
	private String type;
	
	private String definition;
	
	private List attributes;
	
	private List indexes;
	
	public TableInfo() {
		name = "";
		type = "";
		definition = "";
		attributes = new ArrayList();
		indexes = new ArrayList();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDefinition() {
		return definition;
	}

	public void setDefinition(String definition) {
		this.definition = definition;
	}
	
	public void addAttribute(AttributeInfo info) {
		info.setParentTable(name);
		attributes.add(info);
	}
	
	public void addAttributes(List attributes) {
		for (Iterator it = attributes.iterator(); it.hasNext(); ) {
			AttributeInfo info = (AttributeInfo) it.next();
			addAttribute(info);
		}
	}
	
	public List getAttributes() {
		return attributes;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setIndexes(List indexes) {
		this.indexes = indexes;
	}
	
	public void addIndex(IndexInfo index) {
		indexes.add(index);
	}
	
	public List getIndexes() {
		return indexes;
	}
}
