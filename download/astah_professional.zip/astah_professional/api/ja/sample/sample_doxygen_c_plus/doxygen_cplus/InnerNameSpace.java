package doxygen_cplus;
/**
 * 
 * this class is the tag of **.xml
 *  the tag is <innernamespace>. the class is named Innernamespace.
 *  the tag is <innernamespace refid>.it is named "refid"
 *  the tag content is <innernamespace></innernamespace>.it is named "value"
 */
public class InnerNameSpace {
	private String refid;

	public String getRefid() {
		return refid;
	}

	public void setRefid(String refid) {
		this.refid = refid;
	}
}